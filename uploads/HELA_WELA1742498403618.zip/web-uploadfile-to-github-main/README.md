# web-uploadfile-to-github
---------
# *EN*
### 📃 T&C
1. Not For Sale!
2. Don't forget give star this repo!
3. Don't use this repository wrong!
4. If you have problem [chat me](https://wa.me/6285147604355)

#  
 
# *ID*
### 📃 S&K
1. Tidak Untuk Dijual!!!
2. Jangan lupa kasih star di ni repo!
3. Jangan salah gunakan repository ini!
4. Jika kamu punya masalah [chat gwejh](https://wa.me/6285147604355)

---------
